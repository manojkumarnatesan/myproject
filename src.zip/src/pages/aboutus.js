import React from "react";

function AboutUsPage() {
  return <div>About Us Page</div>;
}
export default AboutUsPage;
