import React from "react";

function BlogsPage() {
  return <div>Blogs Page</div>;
}
export default BlogsPage;
