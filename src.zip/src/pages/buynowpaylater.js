import React from "react";

function BuyNowPayLaterPage() {
  return <div>Buy Now Pay Later Page</div>;
}
export default BuyNowPayLaterPage;
