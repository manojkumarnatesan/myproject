import React from "react";

function VideosPage() {
  return  (
    <div>
      <a href= "https://www.youtube.com/channel/UCCIs3vb1mC15PrdPQBwgdjQ" target="_blank" rel="noopener noreferrer">
        Visit Paperplane videos
      </a>
    </div>

  )
  
};

export default VideosPage;
